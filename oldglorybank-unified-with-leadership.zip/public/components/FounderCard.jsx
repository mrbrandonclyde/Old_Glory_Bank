// Placeholder for components/FounderCard.jsx
