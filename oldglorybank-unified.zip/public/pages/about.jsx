// Placeholder for pages/about.jsx
