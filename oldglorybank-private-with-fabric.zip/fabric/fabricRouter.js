// Placeholder for fabric/fabricRouter.js
