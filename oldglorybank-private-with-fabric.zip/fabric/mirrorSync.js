// Placeholder for fabric/mirrorSync.js
