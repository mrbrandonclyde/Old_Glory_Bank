// Stub for components/MissionMap.jsx
