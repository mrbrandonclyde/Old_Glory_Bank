// Stub for components/FounderCard.jsx
