// Stub for pages/about.jsx
