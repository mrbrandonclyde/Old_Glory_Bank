// Stub for pages/index.jsx
