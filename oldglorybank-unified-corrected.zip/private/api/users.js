// Stub for api/users.js
