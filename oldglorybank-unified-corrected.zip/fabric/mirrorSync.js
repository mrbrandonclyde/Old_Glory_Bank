// Stub for mirrorSync.js
