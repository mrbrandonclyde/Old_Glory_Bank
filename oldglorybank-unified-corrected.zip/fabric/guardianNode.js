// Stub for guardianNode.js
