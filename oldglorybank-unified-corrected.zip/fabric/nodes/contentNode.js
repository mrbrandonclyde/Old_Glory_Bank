// Stub for nodes/contentNode.js
