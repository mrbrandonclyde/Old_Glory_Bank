// Stub for nodes/transactionNode.js
