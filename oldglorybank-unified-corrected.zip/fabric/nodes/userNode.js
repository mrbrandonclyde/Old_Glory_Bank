// Stub for nodes/userNode.js
