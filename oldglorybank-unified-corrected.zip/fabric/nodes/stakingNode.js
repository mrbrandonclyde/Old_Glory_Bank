// Stub for nodes/stakingNode.js
