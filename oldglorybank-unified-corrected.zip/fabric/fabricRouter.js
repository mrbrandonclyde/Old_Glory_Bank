// Stub for fabricRouter.js
